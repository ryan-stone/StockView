package com.example.stockview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    final int numStocks = 22;

    String range = "1d";
    Card card[] = new Card[numStocks];
    //StockViewGroup stockViewGroup[] = new StockViewGroup[numStocks];

    TextView nameView[] = new TextView[numStocks];
    TextView percentView[] = new TextView[numStocks];
    TextView priceView[] = new TextView[numStocks];

    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Stock apple = new Stock("AAPL");
        Stock google = new Stock("GOOGL");
        Stock facebook = new Stock("FB");
        Stock tesla = new Stock("TSLA");
        Stock starbucks = new Stock("SBUX");
        Stock disney = new Stock("DIS");
        Stock microsoft = new Stock("MSFT");
        Stock netflix = new Stock("NFLX");
        Stock twitter = new Stock("TWTR");
        Stock aurora_cannabis = new Stock ("ACB");
        Stock gopro = new Stock("GPRO");
        Stock sears = new Stock("SHOS");
        Stock amazon = new Stock("AMZN");
        Stock fitbit = new Stock("FIT");
        Stock amd = new Stock("AMD");
        Stock snapchat = new Stock("SNAP");
        Stock zynga = new Stock("ZNGA");
        Stock square = new Stock("SQ");
        Stock sprint = new Stock("S");
        Stock lyft = new Stock("LYFT");
        Stock paypal = new Stock("PYPL");
        Stock tencent = new Stock("TCEHY");

        card[0] = new Card(google);
        card[1] = new Card(apple);
        card[2] = new Card(facebook);
        card[3] = new Card(tesla);
        card[4] = new Card(starbucks);
        card[5] = new Card(disney);
        card[6] = new Card(microsoft);
        card[7] = new Card(netflix);
        card[8] = new Card(twitter);
        card[9] = new Card(aurora_cannabis);
        card[10] = new Card(gopro);
        card[11] = new Card(sears);
        card[12] = new Card(amazon);
        card[13] = new Card(fitbit);
        card[14] = new Card(amd);
        card[15] = new Card(snapchat);
        card[16] = new Card(zynga);
        card[17] = new Card(square);
        card[18] = new Card(sprint);
        card[19] = new Card(lyft);
        card[20] = new Card(paypal);
        card[21] = new Card(tencent);


        //sortCards(card, range);

        nameView[0] = (TextView) findViewById(R.id.stock0);
        nameView[1] = (TextView) findViewById(R.id.stock1);
        nameView[2] = (TextView) findViewById(R.id.stock2);
        nameView[3] = (TextView) findViewById(R.id.stock3);
        nameView[4] = (TextView) findViewById(R.id.stock4);
        nameView[5] = (TextView) findViewById(R.id.stock5);
        nameView[6] = (TextView) findViewById(R.id.stock6);
        nameView[7] = (TextView) findViewById(R.id.stock7);
        nameView[8] = (TextView) findViewById(R.id.stock8);
        nameView[9] = (TextView) findViewById(R.id.stock9);
        nameView[10] = (TextView) findViewById(R.id.stock10);
        nameView[11] = (TextView) findViewById(R.id.stock11);
        nameView[12] = (TextView) findViewById(R.id.stock12);
        nameView[13] = (TextView) findViewById(R.id.stock13);
        nameView[14] = (TextView) findViewById(R.id.stock14);
        nameView[15] = (TextView) findViewById(R.id.stock15);
        nameView[16] = (TextView) findViewById(R.id.stock16);
        nameView[17] = (TextView) findViewById(R.id.stock17);
        nameView[18] = (TextView) findViewById(R.id.stock18);
        nameView[19] = (TextView) findViewById(R.id.stock19);
        nameView[20] = (TextView) findViewById(R.id.stock20);
        nameView[21] = (TextView) findViewById(R.id.stock21);


        priceView[0] = (TextView) findViewById(R.id.price0);
        priceView[1] = (TextView) findViewById(R.id.price1);
        priceView[2] = (TextView) findViewById(R.id.price2);
        priceView[3] = (TextView) findViewById(R.id.price3);
        priceView[4] = (TextView) findViewById(R.id.price4);
        priceView[5] = (TextView) findViewById(R.id.price5);
        priceView[6] = (TextView) findViewById(R.id.price6);
        priceView[7] = (TextView) findViewById(R.id.price7);
        priceView[8] = (TextView) findViewById(R.id.price8);
        priceView[9] = (TextView) findViewById(R.id.price9);
        priceView[10] = (TextView) findViewById(R.id.price10);
        priceView[11] = (TextView) findViewById(R.id.price11);
        priceView[12] = (TextView) findViewById(R.id.price12);
        priceView[13] = (TextView) findViewById(R.id.price13);
        priceView[14] = (TextView) findViewById(R.id.price14);
        priceView[15] = (TextView) findViewById(R.id.price15);
        priceView[16] = (TextView) findViewById(R.id.price16);
        priceView[17] = (TextView) findViewById(R.id.price17);
        priceView[18] = (TextView) findViewById(R.id.price18);
        priceView[19] = (TextView) findViewById(R.id.price19);
        priceView[20] = (TextView) findViewById(R.id.price20);
        priceView[21] = (TextView) findViewById(R.id.price21);

        percentView[0] = (TextView) findViewById(R.id.percent_change0);
        percentView[1] = (TextView) findViewById(R.id.percent_change1);
        percentView[2] = (TextView) findViewById(R.id.percent_change2);
        percentView[3] = (TextView) findViewById(R.id.percent_change3);
        percentView[4] = (TextView) findViewById(R.id.percent_change4);
        percentView[5] = (TextView) findViewById(R.id.percent_change5);
        percentView[6] = (TextView) findViewById(R.id.percent_change6);
        percentView[7] = (TextView) findViewById(R.id.percent_change7);
        percentView[8] = (TextView) findViewById(R.id.percent_change8);
        percentView[9] = (TextView) findViewById(R.id.percent_change9);
        percentView[10] = (TextView) findViewById(R.id.percent_change10);
        percentView[11] = (TextView) findViewById(R.id.percent_change11);
        percentView[12] = (TextView) findViewById(R.id.percent_change12);
        percentView[13] = (TextView) findViewById(R.id.percent_change13);
        percentView[14] = (TextView) findViewById(R.id.percent_change14);
        percentView[15] = (TextView) findViewById(R.id.percent_change15);
        percentView[16] = (TextView) findViewById(R.id.percent_change16);
        percentView[17] = (TextView) findViewById(R.id.percent_change17);
        percentView[18] = (TextView) findViewById(R.id.percent_change18);
        percentView[19] = (TextView) findViewById(R.id.percent_change19);
        percentView[20] = (TextView) findViewById(R.id.percent_change20);
        percentView[21] = (TextView) findViewById(R.id.percent_change21);


        radioGroup = (RadioGroup) findViewById(R.id.filter_radio_group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.filter_1d:
                        range = "1d";
                        break;
                    case R.id.filter_1w:
                        range = "1w";
                        break;
                    case R.id.filter_1m:
                        range = "1m";
                        break;
                    case R.id.filter_3m:
                        range = "3m";
                        break;
                        /*
                    case R.id.filter_1y:
                        range = "1y";
                        break;
                    case R.id.filter_5y:
                        range = "5y";
                        break;*/
                }
                sortCards(card, range);
                refresh();
            }
        });

        Button refreshButton = findViewById(R.id.refresh_button);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                refresh();
            }
        });

    }


    /* Selection Sort */
    public void sortCards(Card card[], String range){
        Card tempCard;
        double highest;
        int highestIndex;

        for (int i = 0; i < card.length; i++){
            highest = card[i].stock.getPercent(range);
            highestIndex = i;
            for (int j = i+1; j < card.length; j++){
                if (card[j].stock.getPercent(range) > highest){
                    highest = card[j].stock.getPercent(range);
                    highestIndex = j;
                }
            }
            tempCard = card[i];
            card[i] = card[highestIndex];
            card[highestIndex] = tempCard;
        }
    }


    public void refresh() {

        for (int i = 0; i < card.length; i++){
            card[i].stock.parse();
        }
        sortCards(card, range);

        for (int i = 0; i < numStocks; i++){
            nameView[i].setText(card[i].stock.getName());
            priceView[i].setText("$" + Double.toString(card[i].stock.getPrice()));
            percentView[i].setText(String.format("%.2f", card[i].stock.getPercent(range)) + "%");

            if (card[i].stock.getPercent(range) >= 0.0) {
                nameView[i].setTextColor(getColor(R.color.colorProfit));
                priceView[i].setTextColor(getColor(R.color.colorProfit));
                percentView[i].setTextColor(getColor(R.color.colorProfit));
            }
            else {
                nameView[i].setTextColor(getColor(R.color.colorLoss));
                priceView[i].setTextColor(getColor(R.color.colorLoss));
                percentView[i].setTextColor(getColor(R.color.colorLoss));
            }
        }

    }
}
