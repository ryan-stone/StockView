package com.example.stockview;

import android.widget.TextView;

public class StockViewGroup {
    Stock stock;
    String range;

    public TextView nameView;
    public TextView priceView;
    public TextView percentView;

    StockViewGroup(Stock s){
        stock = s;
    }

    public void setViews(String range){
        nameView.setText(stock.getName());
        String currentPrice = "$" + Double.toString(stock.getPrice());
        priceView.setText(currentPrice);
        percentView.setText(String.format("%.2f", stock.getPercent(range)) + "%");
    }
}
