package com.example.stockview;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Stock {
    private double price, price_1d, price_1w, price_1m, price_3m, price_1y, price_5y;
    private String name;
    private Document document;
    private String url;



    public Stock(String n){
        name = n;
        this.price = 0;
        this.price_1d = 0;
        this.price_1w = 0;
        this.price_1m = 0;
        this.price_3m = 0;

        parse();
    }



    public double getPercent(String range) {
        double oldPrice;

        if (range.equals("1d")) oldPrice = price_1d;
        else if (range.equals("1w")) oldPrice = price_1w;
        else if (range.equals("1m")) oldPrice = price_1m;
        else if (range.equals("3m")) oldPrice = price_3m;
        else if (range.equals("1y")) oldPrice = price_1y;
        else if (range.equals("5y")) oldPrice = price_5y;
        else oldPrice = price;

        if (oldPrice != 0)
            return 100*(price/oldPrice - 1);
        else return 0;
    }

    public String getName() { return name; }

    public double getPrice() {
        parse();
        return price;
    }

    public String getUrl(String name){
        url = "https://finance.yahoo.com/quote/" + name + "/history?p=" + name;
        return url;
    }

    public void parse(){
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                try  {
                    document = Jsoup.connect(getUrl(name)).get();
                    String elementAttempt;

                    Elements todayClose = document.select("span[data-reactid='61']");
                    elementAttempt = todayClose.get(0).text().replace(",", "");
                    price = Double.parseDouble(elementAttempt);

                    Elements close1d = document.select("span[data-reactid='76']");
                    price_1d = Double.parseDouble(close1d.get(0).text().replace(",", ""));

                    Elements close1w = document.select("span[data-reactid='136']");
                    price_1w = Double.parseDouble(close1w.get(0).text().replace(",", ""));

                    Elements close1m = document.select("span[data-reactid='361']");
                    price_1m = Double.parseDouble(close1m.get(0).text().replace(",", ""));

                    Elements close3m = document.select("span[data-reactid='998']");
                    elementAttempt = close3m.get(0).text().replace(",", "");
                    if (elementAttempt.contains("Jan") || elementAttempt.contains("Feb") ||
                            elementAttempt.contains("Mar") || elementAttempt.contains("Apr") ||
                            elementAttempt.contains("May") || elementAttempt.contains("Jun") ||
                            elementAttempt.contains("Jul") || elementAttempt.contains("Aug") ||
                            elementAttempt.contains("Sep") || elementAttempt.contains("Oct") ||
                            elementAttempt.contains("Nov") || elementAttempt.contains("Dec")){
                        close3m = document.select("span[data-reactid='991']");
                        elementAttempt = close3m.get(0).text().replace(",", "");
                    }
                    price_3m = Double.parseDouble(elementAttempt);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();
    }
}
