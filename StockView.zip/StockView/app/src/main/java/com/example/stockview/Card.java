package com.example.stockview;

import android.widget.TextView;

public class Card {
    public Stock stock;
    public Card(Stock s){
        stock = s;
    }
    public void setStock(Stock s) { stock = s; }
}
