StockView
Ryan Stone
Alpha Version
4/18/2019

****************************
*--------READ ME-----------*
****************************

-----------USAGE------------
Must have internet connection to run the app.

If you have internet connection and the app starts
but the stocks display values of 0, hit the refresh button
or change the sorting value by tapping one of the radio buttons.

When changing orientations, you will need to tap the refresh button.

The app can be slow sometimes, so give it a few seconds to refresh.

-----------INFO-------------
Stock prices are scraped from finance.yahoo.com using the
JSoup web parsing libray.

Performance is measured as % Change using the follwing formula:

	%change = 100 * (currentPrice - oldPrice)/oldPrice


-----------NOTES-------------
Originally I had intended to use historic prices as far
back as 5 years, but due to limitations with yahoo finance,
I was only able to go back 3 months.

Stocks displayed on the app were chosen arbitrarily. Stocks that returned dividends could not be displayed using YF. 

----------FUTURE DEVELOPMENT-----------
This app is a proof of concept rather than a fully fleshed out, marketable product. In the future I would like to find ways
to make the app more efficient so that I can display more stocks
without slowing down the app. Ideally, I would like to dynamically
display the top 500 most popular (by trade volume) stocks,
INCLUDING stocks that pay out dividends.

Getting data from every major stock is a challenge without
using a stock API. The reason I don't use one currently is 
that in order to get consistent live data, you need to pay
to use the APIs. Eventually I would like to transition to
an API, as it would be a more reliable source of data than
parsing HTML documents with JSoup. Some of the APIs I looked at
return data in JSON (JavaScript output notation), so I will have to
figure out how to integrate that with Android studio.

One way I could make the tracker more efficient would be to
dynamically display stock views. This could be done by using
a ListView layout instead of a ScrollView layout.